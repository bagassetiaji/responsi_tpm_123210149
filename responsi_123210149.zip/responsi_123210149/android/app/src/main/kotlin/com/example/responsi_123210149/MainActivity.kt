package com.example.responsi_123210149

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
